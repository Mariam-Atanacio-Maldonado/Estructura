#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;
using namespace msclr::interop;

class NODO
{
	string letra;
	int numero;
public:
	NODO(void);
	string Get_letra();
	int Get_numero();
	void Set_letra(string l);
	void Set_numero(int n);
};

