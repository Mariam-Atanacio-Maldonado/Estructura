#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "COLA.h"
using namespace System::Windows::Forms;
using namespace std;
using namespace msclr::interop;

class ENTRADA_SALIDA
{
public:
	ENTRADA_SALIDA(void);
	void Tamano_cola(TextBox^ ttamano, DataGridView^ grilla);
	void Insertar_cola(DataGridView^ grilla, COLA &cola);
	void Mostrar_cola(DataGridView^ grillacola, COLA cola);
	void EliminarUno(COLA &cola);
	int Longitud(COLA cola);
};