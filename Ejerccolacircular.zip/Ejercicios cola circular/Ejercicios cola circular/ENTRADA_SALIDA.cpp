#include "StdAfx.h"
#include "ENTRADA_SALIDA.h"


ENTRADA_SALIDA::ENTRADA_SALIDA(void)
{
}
void ENTRADA_SALIDA::Tamano_cola(TextBox^ ttamano, DataGridView^ grilla)
{
	grilla->ColumnCount=System::Convert::ToInt32(ttamano->Text);
	grilla->RowCount=2;
}
void ENTRADA_SALIDA::Insertar_cola(DataGridView^ grilla, COLA &cola)
{
	int i; i=0;
	NODO barra;
	while(i<grilla->ColumnCount)
	{
		barra.Set_letra(marshal_as<std::string>(System::Convert::ToString(grilla->Rows[0]->Cells[i]->Value)));
		barra.Set_numero(System::Convert::ToInt32(grilla->Rows[1]->Cells[i]->Value));
		
		if(cola.Insertar(barra)==false)
		{
			MessageBox::Show("cola llena", System::Convert::ToString(cola.Frente()));
		}
		i++;
	}
}
void ENTRADA_SALIDA::Mostrar_cola(DataGridView^ grillacola, COLA cola)
{
	grillacola->RowCount=2;
	grillacola->ColumnCount=Longitud(cola);

	COLA aux;
	aux=cola;
	int i; i=0;

	NODO barra;
		
	while(aux.Colavacia()==false)
	{
		aux.Eliminar(barra);
		grillacola->Rows[0]->Cells[i]->Value=marshal_as<System::String^>(barra.Get_letra());
		grillacola->Rows[1]->Cells[i]->Value=System::Convert::ToString(barra.Get_numero());
		i++;
	}

}
void ENTRADA_SALIDA::EliminarUno(COLA &cola)
{
	NODO barra;
	cola.Eliminar(barra);
	MessageBox::Show("Dato eliminado", marshal_as<System::String^>(barra.Get_letra()));
}
int ENTRADA_SALIDA::Longitud(COLA cola)
{
	COLA aux;
	NODO barra;
	aux=cola;
	int i; i=0;

	while(aux.Colavacia()==false)
	{
		aux.Eliminar(barra);
		i++;
	}
	return i;
}