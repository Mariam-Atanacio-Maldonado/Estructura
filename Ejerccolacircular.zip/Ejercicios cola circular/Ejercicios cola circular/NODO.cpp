#include "StdAfx.h"
#include "NODO.h"


NODO::NODO(void)
{
	letra="";
	numero=0;
}
string NODO::Get_letra()
{
	return letra;
}
int NODO::Get_numero()
{
	return numero;
}
void NODO::Set_letra(string l)
{
	letra=l;
}
void NODO::Set_numero(int n)
{
	numero=n;
}