#pragma once
#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "COLA.h"
#include "ENTRADA_SALIDA.h"
#include "OPERACIONES.h"


namespace Ejercicioscolacircular {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	COLA cola;
	ENTRADA_SALIDA io;
	OPERACIONES op;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::DataGridView^  grillacola;
	protected: 

	protected: 

	private: System::Windows::Forms::TextBox^  tTAMANO;
	private: System::Windows::Forms::TextBox^  tNUMERO;
	private: System::Windows::Forms::TextBox^  tLETRA;
	private: System::Windows::Forms::TextBox^  tPOS2;
	private: System::Windows::Forms::TextBox^  tPOS;
	private: System::Windows::Forms::Button^  bEJERCICIO1;
	private: System::Windows::Forms::Button^  bTAMANO;
	private: System::Windows::Forms::Button^  bELIMINAR;
	private: System::Windows::Forms::Button^  bMOSTRAR;
	private: System::Windows::Forms::Button^  bINSERTAR;
	private: System::Windows::Forms::Button^  bEJERCICIO11;
	private: System::Windows::Forms::Button^  bEJERCICIO10;
	private: System::Windows::Forms::Button^  bEJERCICIO9;
	private: System::Windows::Forms::Button^  bEJERCICIO7;
	private: System::Windows::Forms::Button^  bEJERCICIO6;
	private: System::Windows::Forms::Button^  bEJERCICIO4;
	private: System::Windows::Forms::Button^  bEJERCICIO2;
	private: System::Windows::Forms::Button^  bEJERCICIO3;
	private: System::Windows::Forms::TextBox^  tPOS3;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->grillacola = (gcnew System::Windows::Forms::DataGridView());
			this->tTAMANO = (gcnew System::Windows::Forms::TextBox());
			this->tNUMERO = (gcnew System::Windows::Forms::TextBox());
			this->tLETRA = (gcnew System::Windows::Forms::TextBox());
			this->tPOS2 = (gcnew System::Windows::Forms::TextBox());
			this->tPOS = (gcnew System::Windows::Forms::TextBox());
			this->bEJERCICIO1 = (gcnew System::Windows::Forms::Button());
			this->bTAMANO = (gcnew System::Windows::Forms::Button());
			this->bELIMINAR = (gcnew System::Windows::Forms::Button());
			this->bMOSTRAR = (gcnew System::Windows::Forms::Button());
			this->bINSERTAR = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO11 = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO10 = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO9 = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO7 = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO6 = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO4 = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO2 = (gcnew System::Windows::Forms::Button());
			this->bEJERCICIO3 = (gcnew System::Windows::Forms::Button());
			this->tPOS3 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillacola))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Location = System::Drawing::Point(85, 81);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(1128, 380);
			this->grilla->TabIndex = 0;
			// 
			// grillacola
			// 
			this->grillacola->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillacola->Location = System::Drawing::Point(1098, 567);
			this->grillacola->Name = L"grillacola";
			this->grillacola->Size = System::Drawing::Size(1128, 380);
			this->grillacola->TabIndex = 1;
			// 
			// tTAMANO
			// 
			this->tTAMANO->Location = System::Drawing::Point(98, 502);
			this->tTAMANO->Name = L"tTAMANO";
			this->tTAMANO->Size = System::Drawing::Size(290, 35);
			this->tTAMANO->TabIndex = 2;
			// 
			// tNUMERO
			// 
			this->tNUMERO->Location = System::Drawing::Point(1749, 444);
			this->tNUMERO->Name = L"tNUMERO";
			this->tNUMERO->Size = System::Drawing::Size(195, 35);
			this->tNUMERO->TabIndex = 3;
			// 
			// tLETRA
			// 
			this->tLETRA->Location = System::Drawing::Point(1749, 367);
			this->tLETRA->Name = L"tLETRA";
			this->tLETRA->Size = System::Drawing::Size(195, 35);
			this->tLETRA->TabIndex = 4;
			// 
			// tPOS2
			// 
			this->tPOS2->Location = System::Drawing::Point(1749, 301);
			this->tPOS2->Name = L"tPOS2";
			this->tPOS2->Size = System::Drawing::Size(195, 35);
			this->tPOS2->TabIndex = 5;
			// 
			// tPOS
			// 
			this->tPOS->Location = System::Drawing::Point(1749, 231);
			this->tPOS->Name = L"tPOS";
			this->tPOS->Size = System::Drawing::Size(195, 35);
			this->tPOS->TabIndex = 6;
			// 
			// bEJERCICIO1
			// 
			this->bEJERCICIO1->Location = System::Drawing::Point(1295, 110);
			this->bEJERCICIO1->Name = L"bEJERCICIO1";
			this->bEJERCICIO1->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO1->TabIndex = 7;
			this->bEJERCICIO1->Text = L"EJERCICIO1";
			this->bEJERCICIO1->UseVisualStyleBackColor = true;
			this->bEJERCICIO1->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO1_Click);
			// 
			// bTAMANO
			// 
			this->bTAMANO->Location = System::Drawing::Point(415, 484);
			this->bTAMANO->Name = L"bTAMANO";
			this->bTAMANO->Size = System::Drawing::Size(195, 70);
			this->bTAMANO->TabIndex = 8;
			this->bTAMANO->Text = L"TAMANHO";
			this->bTAMANO->UseVisualStyleBackColor = true;
			this->bTAMANO->Click += gcnew System::EventHandler(this, &Form1::bTAMANO_Click);
			// 
			// bELIMINAR
			// 
			this->bELIMINAR->Location = System::Drawing::Point(644, 694);
			this->bELIMINAR->Name = L"bELIMINAR";
			this->bELIMINAR->Size = System::Drawing::Size(195, 70);
			this->bELIMINAR->TabIndex = 9;
			this->bELIMINAR->Text = L"ELIMINAR";
			this->bELIMINAR->UseVisualStyleBackColor = true;
			this->bELIMINAR->Click += gcnew System::EventHandler(this, &Form1::bELIMINAR_Click);
			// 
			// bMOSTRAR
			// 
			this->bMOSTRAR->Location = System::Drawing::Point(644, 586);
			this->bMOSTRAR->Name = L"bMOSTRAR";
			this->bMOSTRAR->Size = System::Drawing::Size(195, 70);
			this->bMOSTRAR->TabIndex = 10;
			this->bMOSTRAR->Text = L"MOSTRAR";
			this->bMOSTRAR->UseVisualStyleBackColor = true;
			this->bMOSTRAR->Click += gcnew System::EventHandler(this, &Form1::bMOSTRAR_Click);
			// 
			// bINSERTAR
			// 
			this->bINSERTAR->Location = System::Drawing::Point(644, 484);
			this->bINSERTAR->Name = L"bINSERTAR";
			this->bINSERTAR->Size = System::Drawing::Size(195, 70);
			this->bINSERTAR->TabIndex = 11;
			this->bINSERTAR->Text = L"INSERTAR";
			this->bINSERTAR->UseVisualStyleBackColor = true;
			this->bINSERTAR->Click += gcnew System::EventHandler(this, &Form1::bINSERTAR_Click);
			// 
			// bEJERCICIO11
			// 
			this->bEJERCICIO11->Location = System::Drawing::Point(1295, 426);
			this->bEJERCICIO11->Name = L"bEJERCICIO11";
			this->bEJERCICIO11->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO11->TabIndex = 12;
			this->bEJERCICIO11->Text = L"EJERCICIO11";
			this->bEJERCICIO11->UseVisualStyleBackColor = true;
			this->bEJERCICIO11->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO11_Click);
			// 
			// bEJERCICIO10
			// 
			this->bEJERCICIO10->Location = System::Drawing::Point(1524, 322);
			this->bEJERCICIO10->Name = L"bEJERCICIO10";
			this->bEJERCICIO10->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO10->TabIndex = 13;
			this->bEJERCICIO10->Text = L"EJERCICIO10";
			this->bEJERCICIO10->UseVisualStyleBackColor = true;
			this->bEJERCICIO10->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO10_Click);
			// 
			// bEJERCICIO9
			// 
			this->bEJERCICIO9->Location = System::Drawing::Point(1295, 322);
			this->bEJERCICIO9->Name = L"bEJERCICIO9";
			this->bEJERCICIO9->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO9->TabIndex = 14;
			this->bEJERCICIO9->Text = L"EJERCICIO9";
			this->bEJERCICIO9->UseVisualStyleBackColor = true;
			this->bEJERCICIO9->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO9_Click);
			// 
			// bEJERCICIO7
			// 
			this->bEJERCICIO7->Location = System::Drawing::Point(1524, 213);
			this->bEJERCICIO7->Name = L"bEJERCICIO7";
			this->bEJERCICIO7->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO7->TabIndex = 15;
			this->bEJERCICIO7->Text = L"EJERCICIO7";
			this->bEJERCICIO7->UseVisualStyleBackColor = true;
			this->bEJERCICIO7->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO7_Click);
			// 
			// bEJERCICIO6
			// 
			this->bEJERCICIO6->Location = System::Drawing::Point(1295, 213);
			this->bEJERCICIO6->Name = L"bEJERCICIO6";
			this->bEJERCICIO6->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO6->TabIndex = 16;
			this->bEJERCICIO6->Text = L"EJERCICIO6";
			this->bEJERCICIO6->UseVisualStyleBackColor = true;
			this->bEJERCICIO6->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO6_Click);
			// 
			// bEJERCICIO4
			// 
			this->bEJERCICIO4->Location = System::Drawing::Point(1966, 110);
			this->bEJERCICIO4->Name = L"bEJERCICIO4";
			this->bEJERCICIO4->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO4->TabIndex = 17;
			this->bEJERCICIO4->Text = L"EJERCICIO4";
			this->bEJERCICIO4->UseVisualStyleBackColor = true;
			this->bEJERCICIO4->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO4_Click);
			// 
			// bEJERCICIO2
			// 
			this->bEJERCICIO2->Location = System::Drawing::Point(1524, 110);
			this->bEJERCICIO2->Name = L"bEJERCICIO2";
			this->bEJERCICIO2->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO2->TabIndex = 18;
			this->bEJERCICIO2->Text = L"EJERCICIO2";
			this->bEJERCICIO2->UseVisualStyleBackColor = true;
			this->bEJERCICIO2->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO2_Click);
			// 
			// bEJERCICIO3
			// 
			this->bEJERCICIO3->Location = System::Drawing::Point(1749, 110);
			this->bEJERCICIO3->Name = L"bEJERCICIO3";
			this->bEJERCICIO3->Size = System::Drawing::Size(195, 70);
			this->bEJERCICIO3->TabIndex = 19;
			this->bEJERCICIO3->Text = L"EJERCICIO3";
			this->bEJERCICIO3->UseVisualStyleBackColor = true;
			this->bEJERCICIO3->Click += gcnew System::EventHandler(this, &Form1::bEJERCICIO3_Click);
			// 
			// tPOS3
			// 
			this->tPOS3->Location = System::Drawing::Point(1295, 502);
			this->tPOS3->Name = L"tPOS3";
			this->tPOS3->Size = System::Drawing::Size(195, 35);
			this->tPOS3->TabIndex = 20;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(1982, 309);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(130, 29);
			this->label1->TabIndex = 21;
			this->label1->Text = L"POSICION";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(1982, 450);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(120, 29);
			this->label2->TabIndex = 22;
			this->label2->Text = L"NUMERO";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(1982, 373);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(90, 29);
			this->label3->TabIndex = 23;
			this->label3->Text = L"LETRA";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(14, 29);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(2288, 1003);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->tPOS3);
			this->Controls->Add(this->bEJERCICIO3);
			this->Controls->Add(this->bEJERCICIO2);
			this->Controls->Add(this->bEJERCICIO4);
			this->Controls->Add(this->bEJERCICIO6);
			this->Controls->Add(this->bEJERCICIO7);
			this->Controls->Add(this->bEJERCICIO9);
			this->Controls->Add(this->bEJERCICIO10);
			this->Controls->Add(this->bEJERCICIO11);
			this->Controls->Add(this->bINSERTAR);
			this->Controls->Add(this->bMOSTRAR);
			this->Controls->Add(this->bELIMINAR);
			this->Controls->Add(this->bTAMANO);
			this->Controls->Add(this->bEJERCICIO1);
			this->Controls->Add(this->tPOS);
			this->Controls->Add(this->tPOS2);
			this->Controls->Add(this->tLETRA);
			this->Controls->Add(this->tNUMERO);
			this->Controls->Add(this->tTAMANO);
			this->Controls->Add(this->grillacola);
			this->Controls->Add(this->grilla);
			this->Name = L"Form1";
			this->Text = L"Form1";
			
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillacola))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
	private: System::Void bEJERCICIO1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int o;
			 o=op.Ejercicio1(cola);
			 MessageBox::Show(System::Convert::ToString(o), "Nro elementos");
		 }
			 

private: System::Void bEJERCICIO2_Click(System::Object^  sender, System::EventArgs^  e) {
			  op.Ejercicio2(cola);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bEJERCICIO3_Click(System::Object^  sender, System::EventArgs^  e) {
		 op.Ejercicio3(cola, tPOS);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bEJERCICIO4_Click(System::Object^  sender, System::EventArgs^  e) {
		 op.Ejercicio4(cola, tLETRA, tNUMERO, tPOS2);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bEJERCICIO6_Click(System::Object^  sender, System::EventArgs^  e) {
		 op.Ejercicio6(cola);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bEJERCICIO7_Click(System::Object^  sender, System::EventArgs^  e) {
		  op.Ejercicio7(cola);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bEJERCICIO9_Click(System::Object^  sender, System::EventArgs^  e) {
		op.Ejercicio9(cola);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bEJERCICIO10_Click(System::Object^  sender, System::EventArgs^  e) {
		 op.Ejercicio10(cola);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bEJERCICIO11_Click(System::Object^  sender, System::EventArgs^  e) {
		op.Ejercicio11(cola, tPOS3);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bELIMINAR_Click(System::Object^  sender, System::EventArgs^  e) {
		  io.EliminarUno(cola);
			 io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bMOSTRAR_Click(System::Object^  sender, System::EventArgs^  e) {
		  io.Mostrar_cola(grillacola, cola);
		 }
private: System::Void bINSERTAR_Click(System::Object^  sender, System::EventArgs^  e) {
		  io.Insertar_cola(grilla, cola);
		 }
private: System::Void bTAMANO_Click(System::Object^  sender, System::EventArgs^  e) {
		 io.Tamano_cola(tTAMANO, grilla);
		 }
};
}

