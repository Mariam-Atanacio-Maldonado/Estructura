#include "StdAfx.h"
#include "OPERACIONES.h"


OPERACIONES::OPERACIONES(void)
{
}
int OPERACIONES::Ejercicio1(COLA &cola)
{
	COLA aux;
	NODO bolsa;
	aux=cola;
	int i; i=0;

	while(aux.Colavacia()==false)
	{
		aux.Eliminar(bolsa);
		i++;
	}
	return i;
}
void OPERACIONES::Ejercicio2(COLA &cola)
{
	COLA aux2;
	NODO bolsa1, bolsa2;

	while(cola.Colavacia()==false)
	{
		cola.Eliminar(bolsa1);
		COLA aux1;
		while(cola.Colavacia()==false)
		{
			bolsa2=bolsa1;
			aux1.Insertar(bolsa2);
			cola.Eliminar(bolsa1);
		}
		aux2.Insertar(bolsa1);
		cola=aux1;
	}
	cola=aux2;
}
void OPERACIONES::Ejercicio3(COLA &cola, TextBox^ pos)
{
	COLA aux;
	NODO barra;
	int p=1;
	int top=System::Convert::ToInt32(pos->Text);

	while(p<top)
	{
		cola.Eliminar(barra);
		aux.Insertar(barra);
		p++;
	}

	cola.Eliminar(barra);

	while(cola.Colavacia()==false)
	{
		cola.Eliminar(barra);
		aux.Insertar(barra);
	}
	cola=aux;
}
void OPERACIONES::Ejercicio4(COLA &cola, TextBox^ dato, TextBox^ numero, TextBox^ pos)
{
	COLA aux;
	NODO barra;
	int p=System::Convert::ToInt32(pos->Text);
	int top=1;

	while(top<p)
	{
		cola.Eliminar(barra);
		aux.Insertar(barra);
		top++;
	}
	
	barra.Set_letra(marshal_as<std::string>(System::Convert::ToString(dato->Text)));
	barra.Set_numero(System::Convert::ToInt32(numero->Text));
	aux.Insertar(barra);

	while(cola.Colavacia()==false)
	{
		cola.Eliminar(barra);
		aux.Insertar(barra);
	}
	cola=aux;
}
void OPERACIONES::Ejercicio6(COLA &cola)
{
	COLA par, impar;
	NODO bolsa1, bolsa2;

	while(cola.Colavacia()==false)
	{
		cola.Eliminar(bolsa1);
		COLA aux;
		while(cola.Colavacia()==false)
		{
			bolsa2=bolsa1;
			aux.Insertar(bolsa2);
			cola.Eliminar(bolsa1);
		}
		
		if(bolsa1.Get_numero()%2==0)
		{ par.Insertar(bolsa1); }
		else
		{ impar.Insertar(bolsa1); }
		cola=aux;
	}

	while(par.Colavacia()==false)
	{
		par.Eliminar(bolsa2);
		cola.Insertar(bolsa2);
	}

	while(impar.Colavacia()==false)
	{
		impar.Eliminar(bolsa2);
		cola.Insertar(bolsa2);
	}
}
void OPERACIONES::Ejercicio7(COLA &cola)
{
	NODO dato, pendiente, mayor;
	COLA aux;

	while(cola.Colavacia()==false)
	{
		COLA auxMay, auxSinMayor;
		cola.Eliminar(dato);
		pendiente=dato;
		mayor.Set_numero(-1);

		while(cola.Colavacia()==false)
		{
			cola.Eliminar(dato);
			if(dato.Get_numero()>mayor.Get_numero())
			{
				mayor=dato;
			}
			auxMay.Insertar(dato);
		}
		cola=auxMay;

		if(pendiente.Get_numero()>mayor.Get_numero())
		{
			aux.Insertar(pendiente);
			while(cola.Colavacia()==false)
			{
				cola.Eliminar(dato);
				if(dato.Get_numero()!=pendiente.Get_numero())
				{ auxSinMayor.Insertar(dato); }
			}
			cola=auxSinMayor;
			if(cola.Colavacia()==false)
			{ cola.Insertar(mayor); }
			else
			{ aux.Insertar(pendiente); }
		}


		else
		{
			aux.Insertar(mayor);
			while(cola.Colavacia()==false)
			{
				cola.Eliminar(dato);
				if(dato.Get_numero()!=mayor.Get_numero())
				{
					auxSinMayor.Insertar(dato);
				}
			}
			cola=auxSinMayor;
			if(cola.Colavacia()==false)
			{ cola.Insertar(pendiente); }
		}

	}
	cola=aux;
}

void OPERACIONES::Ejercicio9(COLA &cola)
{
	COLA aux;
	NODO barra1, barra2;

	while(cola.Colavacia()==false)
	{
		COLA cola2;
		cola.Eliminar(barra1);
		while(cola.Colavacia()==false)
		{
			cola.Eliminar(barra2);
			if(barra1.Get_numero()!=barra2.Get_numero())
			{ cola2.Insertar(barra2); }
		}
		cola=cola2;
		aux.Insertar(barra1);
	}
	cola=aux;
}
void OPERACIONES::Ejercicio10(COLA &cola)
{
	COLA aux;
	NODO barra;

	while(cola.Colavacia()==false)
	{
		cola.Eliminar(barra);
		if(barra.Get_numero()%2!=0)
		{ aux.Insertar(barra); }
	}
	cola=aux;
}

void OPERACIONES::Ejercicio11(COLA &cola, TextBox^ num)
{
	int p, j=2, np, i=1, suma=0, n;
	int cant=System::Convert::ToInt32(num->Text);
	NODO dato, dato1, dato2;
	COLA aux;
	dato.Set_numero(2);
	cola.Insertar(dato);
	aux.Insertar(dato);
	while(i<cant)
	{
		np=0;
		suma=0;
		j++;
		for(p=2; p<j; p++)
		{
			if(j%p==0)
			{ np=1; }
		}
		if(np==0)
		{
			dato.Set_numero(j);
			cola.Insertar(dato);
			i++;
			n=j;
			while(n!=0)
			{
				suma=n%10+suma;
			    n=n/10;
			}
			dato1.Set_numero(suma);
			aux.Insertar(dato1);
		}
	
	}

	Ejercicio9(aux);

	while(aux.Colavacia()==false)
	{
		aux.Eliminar(dato2);
		cola.Insertar(dato2);
	}
}
