#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "COLA.h"
#include "ENTRADA_SALIDA.h"
using namespace std;
using namespace msclr::interop;
using namespace System::Windows::Forms;

class OPERACIONES
{
public:
	OPERACIONES(void);
	int Ejercicio1(COLA &cola);
	void Ejercicio2(COLA &cola);
	void Ejercicio3(COLA &cola, TextBox^ pos);
	void Ejercicio4(COLA &cola, TextBox^ dato, TextBox^ numero, TextBox^ pos);
	void Ejercicio6(COLA &cola);
	void Ejercicio7(COLA &cola);
	void Ejercicio9(COLA &cola);
	void Ejercicio10(COLA &cola);
	void Ejercicio11(COLA &cola, TextBox^ num);
};

