#include "StdAfx.h"
#include "COLA.h"


COLA::COLA(void)
{
	frente=0;
	final=0;
}
bool COLA::Colavacia()
{
	if(frente==final)
	{ return true; }
	else
	{ return false; }
}
bool COLA::Colallena()
{
	if(((final+1)%A)==frente)
	{ return true; }
	else
	{ return false; }
}
bool COLA::Insertar(NODO t)
{
	if(Colallena()==true)
	{ return false; }
	else
	{
		final=(final+1)%A;
		cola[final]=t;
		return true;
	}
}
bool COLA::Eliminar(NODO &t)
{
	if(Colavacia()==true)
	{ return false; }
	else
	{
		frente=(frente+1)%A;
		t=cola[frente];
		return true;
	}
}
int COLA::Frente()
{ return frente; }
