#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "NODO.h"
using namespace std;
using namespace msclr::interop;
const int A=100;

class COLA
{
	NODO cola[A];
	int frente;
	int final;
public:
	COLA(void);
	bool Colavacia();
	bool Colallena();
	bool Insertar(NODO t);
	bool Eliminar(NODO &t);
	int Frente();
};
